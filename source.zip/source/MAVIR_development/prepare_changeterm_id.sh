awk '{print tolower($1) " " $2 " " $3 " " $4 " " $3-$2}' mavir03.words.txt > mavir03_lower.words.txt
awk '{print $1 " " $2 " " $5 " " $4 " mavir03"}' mavir03_lower.words.txt > mavir03_lower.words.time.score.txt
sed -i 's/telekom/telecom/g' mavir03_lower.words.time.score.txt
sed -i 's/11811/once_ocho_once/g' mavir03_lower.words.time.score.txt
cp mavir03_lower.words.time.score.txt mavir03_lower.words_id.time.score.txt

awk '{print tolower($1) " " $2 " " $3 " " $4 " " $3-$2}' mavir07.words.txt > mavir07_lower.words.txt
awk '{print $1 " " $2 " " $5 " " $4 " mavir07"}' mavir07_lower.words.txt > mavir07_lower.words.time.score.txt
sed -i 's/telekom/telecom/g' mavir07_lower.words.time.score.txt
sed -i 's/11811/once_ocho_once/g' mavir07_lower.words.time.score.txt
cp mavir07_lower.words.time.score.txt mavir07_lower.words_id.time.score.txt


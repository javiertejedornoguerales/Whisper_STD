awk 'BEGIN {inicio=0;} {if ($1 ~ /words/) inicio=1; else if (inicio==1) {if (($1 ~ /text/) || ($1 ~ /start/) || ($1 ~ /end/) || ($1 ~ /confidence/)) print $2;} if ($1 ~ /]/) inicio=0;}' mavir03.wav.words.json > mavir03.words.tmp.txt
sed -i 's/\"//g' mavir03.words.tmp.txt
sed -i 's/,//g' mavir03.words.tmp.txt
paste -d' ' - - - - < mavir03.words.tmp.txt > mavir03.words.tmp2.txt
awk '{gsub(/[^[:alnum:][:space:]]/,"",$1)} 1' mavir03.words.tmp2.txt > mavir03.words.txt

awk 'BEGIN {inicio=0;} {if ($1 ~ /words/) inicio=1; else if (inicio==1) {if (($1 ~ /text/) || ($1 ~ /start/) || ($1 ~ /end/) || ($1 ~ /confidence/)) print $2;} if ($1 ~ /]/) inicio=0;}' mavir07.wav.words.json > mavir07.words.tmp.txt
sed -i 's/\"//g' mavir07.words.tmp.txt
sed -i 's/,//g' mavir07.words.tmp.txt
paste -d' ' - - - - < mavir07.words.tmp.txt > mavir07.words.tmp2.txt
awk '{gsub(/[^[:alnum:][:space:]]/,"",$1)} 1' mavir07.words.tmp2.txt > mavir07.words.txt

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LONG_TERM 2048
#define MAX_NUMBER_TERMS 1024
#define MAX_WORDS_TERM 10
#define MAX_LONG_WORD 128
#define MAX_NUMBER_WORDS 25000
#define MAX_LONG_LINE 2048

typedef struct {

	char **strWord;
	int iNumberWords;

} MultiwordTerm;

typedef struct {

	char *strDetection;
	double dStartTime;
	double dDuration;
	double dScore;
	char *strFilename;
	
} Detection;

int multiword_detection (char *strMultiwordTermListFile, char *strInputDetectionFile, char *strOutputDetectionFile);

int main (int argc, char *argv[]) {

	if (argc!=4) {
		printf ("USAGE: multiword_detection <input multi-word term list file> <input detection file> <output multi-word detection file>\n");
		return -1;
	}
	
	multiword_detection (argv[1],argv[2],argv[3]);
	return 0;
	
}

int multiword_detection (char *strMultiwordTermListFile, char *strInputDetectionFile, char *strOutputDetectionFile) {

	FILE *fMultiwordTermListFile, *fInputDetectionFile, *fOutputDetectionFile;
	char strMultiwordTerm[MAX_LONG_TERM];
	char strDetectionLine[MAX_LONG_LINE];
	MultiwordTerm *pMultiwordTerm;
	int iNumberTerm=0,iNumberWord,i,j,iNumberDetection=0,k,iPossibleTerm,iNewWordDetected,l;
	char *token;
	Detection *pDetection;
	double dStartTime,dDuration,dScore;
	
	//open the input and output files	
	fMultiwordTermListFile=fopen(strMultiwordTermListFile,"r");
	if (fMultiwordTermListFile==NULL) {
		printf ("Fail to open %s to read\n",strMultiwordTermListFile);
		return -1;
	} //if (fMultiwordTermListFile
	
	fInputDetectionFile=fopen(strInputDetectionFile,"r");
	if (fInputDetectionFile==NULL) {
		printf ("Fail to open %s to read\n",strInputDetectionFile);
		return -1;
	} //if (fInputDetectionFile
	
	fOutputDetectionFile=fopen(strOutputDetectionFile,"w");
	if (fOutputDetectionFile==NULL) {
		printf ("Fail to open %s to write\n",strOutputDetectionFile);
		return -1;
	} // if (fOutputDetectionFile

	//allocate memory for the multiword terms
	pMultiwordTerm=(MultiwordTerm *) malloc (MAX_NUMBER_TERMS*sizeof(MultiwordTerm));
	if (pMultiwordTerm==NULL) {
		printf ("Fail to allocate memory for multiword term\n");
		return -1;
	} //if (pMultiwordTerm
	for (i=0;i<MAX_NUMBER_TERMS;i++) {
		pMultiwordTerm[i].strWord=(char **) malloc (MAX_WORDS_TERM*sizeof(char *));
		if (pMultiwordTerm[i].strWord==NULL) {
			printf ("Fail to allocate memory for the words of the term\n");
			return -1;
		} //if (pMultiwordTerm[i].strWord
		for (j=0;j<MAX_WORDS_TERM;j++) {
			pMultiwordTerm[i].strWord[j]=(char *) malloc (MAX_LONG_WORD*sizeof(char));
			if (pMultiwordTerm[i].strWord[j]==NULL) {
				printf ("Fail to allocate memory for the words of the term\n");
				return -1;
			} //if (pMultiwordTerm[i].strWord[j]
		} //for (j=0
	} // for (i=0
	
	//allocate memory for the words detected
	pDetection=(Detection *) malloc (MAX_NUMBER_WORDS*sizeof(Detection));
	if (pDetection==NULL) {
		printf ("Fail to allocate memory for detections\n");
		return -1;
	} //if (pDetection
	for (i=0;i<MAX_NUMBER_WORDS;i++) {
		pDetection[i].strDetection=(char *) malloc (MAX_LONG_WORD*sizeof(char));
		if (pDetection[i].strDetection==NULL) {
			printf ("Fail to allocate memory for the detection\n");
			return -1;
		} //if (pDetection[i].strDetection
		pDetection[i].strFilename=(char *) malloc (MAX_LONG_WORD*sizeof(char));
		if (pDetection[i].strFilename==NULL) {
			printf ("Fail to allocate memory for the detection\n");
			return -1;
		} //if (pDetection[i].strFilename
	} //for (i=0
	
	//read and store all the words of each multi-word term in the corresponding struct
	while (1){		
		memset (strMultiwordTerm,'\x0',MAX_LONG_TERM);
		if (fgets(strMultiwordTerm,MAX_LONG_TERM,fMultiwordTermListFile)==NULL)
			break;
		iNumberWord=0;
		memset (pMultiwordTerm[iNumberTerm].strWord[iNumberWord],'\x0',MAX_LONG_WORD);
		token = strtok(strMultiwordTerm, " ");
		memset (pMultiwordTerm[iNumberTerm].strWord[iNumberWord],'\x0',MAX_LONG_WORD);				
		strcpy(pMultiwordTerm[iNumberTerm].strWord[iNumberWord],token);
		iNumberWord++;
		while (1) {
			token = strtok(NULL, " ");
			if (token==NULL) {
				pMultiwordTerm[iNumberTerm].iNumberWords=iNumberWord;
				iNumberTerm++;			
				break;		
			} //if (token
			memset (pMultiwordTerm[iNumberTerm].strWord[iNumberWord],'\x0',MAX_LONG_WORD);				
			strcpy(pMultiwordTerm[iNumberTerm].strWord[iNumberWord],token);
			iNumberWord++;
		} // while (1)
		pMultiwordTerm[iNumberTerm-1].strWord[iNumberWord-1][strlen(pMultiwordTerm[iNumberTerm-1].strWord[iNumberWord-1])-1]='\0'; //remove the end of line
	}
	
	/*
	for (i=0;i<iNumberTerm;i++) {
		printf ("New term with %d words:\n",pMultiwordTerm[i].iNumberWords);
		for (j=0;j<pMultiwordTerm[i].iNumberWords;j++) {
			printf ("%s ",pMultiwordTerm[i].strWord[j]);
		}
		printf ("\n");
	}*/
	
	//read the detection file with the setup: detection, start time, duration, score and filename
	while (1) {
		memset (strDetectionLine,'\x0',MAX_LONG_LINE);
		if (fgets(strDetectionLine,MAX_LONG_LINE,fInputDetectionFile)==NULL)
			break;
		//read the word
		token = strtok(strDetectionLine, " ");
		memset(pDetection[iNumberDetection].strDetection,'\x0',MAX_LONG_WORD);
		strcpy(pDetection[iNumberDetection].strDetection,token);
		//read the start time
		token = strtok(NULL, " ");
		pDetection[iNumberDetection].dStartTime=atof(token);
		//read the duration
		token = strtok(NULL, " ");
		pDetection[iNumberDetection].dDuration=atof(token);
		//read the score
		token = strtok(NULL, " ");
		pDetection[iNumberDetection].dScore=atof(token);
		//read the file name
		token = strtok(NULL, " ");		
		memset(pDetection[iNumberDetection].strFilename,'\x0',MAX_LONG_WORD);
		strcpy(pDetection[iNumberDetection].strFilename,token);
		pDetection[iNumberDetection].strFilename[strlen(pDetection[iNumberDetection].strFilename)-1]='\0'; //remove the end of line
		iNumberDetection++;		
	} //while (1)
		
/*	for (i=0;i<iNumberDetection;i++) 
		printf ("%s %lf %lf %lf %s\n",pDetection[i].strDetection,pDetection[i].dStartTime,pDetection[i].dDuration,pDetection[i].dScore,pDetection[i].strFilename);
*/	

	//find the multi-word terms in the detection struct
	for (i=0;i<iNumberTerm;i++) {
		dDuration=0.0;
		dScore=0.0;
		iPossibleTerm=0;
		iNewWordDetected=0;
		for (k=0;k<iNumberDetection;k++) {
			//if the first word of the term coincides with the current word in the detection file
			if ((strcmp(pMultiwordTerm[i].strWord[iNewWordDetected],pDetection[k].strDetection)==0) && (iNewWordDetected==0)) {				
				dStartTime=pDetection[k].dStartTime;
				dDuration+=pDetection[k].dDuration;
				dScore+=pDetection[k].dScore;
				iPossibleTerm=1; //there is a possible multi-word term
				iNewWordDetected++;
			} // if (strcmp(pMultiwordTerm[i].strWord[j],pDetection[iIndexDetection].strDetection)
			//if the next words of the term coincide with those of the detection file and there is a possible multi-word term
			else if ((strcmp(pMultiwordTerm[i].strWord[iNewWordDetected],pDetection[k].strDetection)==0) && (iPossibleTerm==1)) {
				dDuration+=pDetection[k].dDuration;
				dScore+=pDetection[k].dScore;
				iNewWordDetected++;
				//if the multi-word term is detected
				if (pMultiwordTerm[i].iNumberWords==iNewWordDetected) {
					for (l=0;l<pMultiwordTerm[i].iNumberWords;l++) 
						if (l==pMultiwordTerm[i].iNumberWords-1)
							fprintf (fOutputDetectionFile,"%s ",pMultiwordTerm[i].strWord[l]);
						else
							fprintf (fOutputDetectionFile,"%s_",pMultiwordTerm[i].strWord[l]);
					fprintf (fOutputDetectionFile,"%lf %lf %lf %s\n",dStartTime,dDuration,dScore/pMultiwordTerm[i].iNumberWords,pDetection[k].strFilename);			
				} //if (pMultiwordTerm[i].iNumberWords					
			} //else if (strcmp(pMultiwordTerm[i].strWord[j],pDetection[k].strDetection)
			else {
				if (iPossibleTerm==1)
					k=k-1;
				iPossibleTerm=0;
				iNewWordDetected=0;
				dDuration=0.0;
				dScore=0.0;
			} //else
		} //for (k=0
	} //for (i=0
	
	fclose(fMultiwordTermListFile);
	fclose(fInputDetectionFile);
	fclose(fOutputDetectionFile);
	
	for (i=0;i<MAX_NUMBER_WORDS;i++) {
		free (pDetection[i].strDetection);
		free (pDetection[i].strFilename);
	} //for (i=0
	free (pDetection);

	for (i=0;i<MAX_NUMBER_TERMS;i++) {
		for (j=0;j<MAX_WORDS_TERM;j++) {
			free (pMultiwordTerm[i].strWord[j]);
		} //for (j=0
		free (pMultiwordTerm[i].strWord);		
	} //for (i=0
	free (pMultiwordTerm);
	
	return 0;
}

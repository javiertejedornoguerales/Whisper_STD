awk '{if ($1 ~ /DEV-/) print $1 " " $2 " " $3 " " $4 " " $5}' mavir03_lower.singlemultiwords_id.time.score.txt > mavir03.singlemultiterms.txt
awk '{if ($1 ~ /DEV-/) print $1 " " $2 " " $3 " " $4 " " $5}' mavir07_lower.singlemultiwords_id.time.score.txt > mavir07.singlemultiterms.txt
cat mavir03.singlemultiterms.txt mavir07.singlemultiterms.txt > all.singlemultiterms.txt

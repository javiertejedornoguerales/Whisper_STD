sort all.singlemultiterms.txt > all_order.singlemultiterms.txt

whisper_timestamped mavir03.wav -o mavir03 --model medium --language Spanish --accurate
whisper_timestamped mavir07.wav -o mavir07 --model medium --language Spanish --accurate

./multiword_detection multiword_terms_STD_MAVIR_test.txt mavir04_lower.words.time.score.txt mavir04_multiwordterms.txt
cp mavir04_multiwordterms.txt mavir04_multiwordterms_id.txt
sed -i 's/\bantonio_moreno\b/TEST-0006/g' mavir04_multiwordterms_id.txt
sed -i 's/\bcoca_cola\b/TEST-0023/g' mavir04_multiwordterms_id.txt
sed -i 's/\bconsorcio_mavir\b/TEST-0030/g' mavir04_multiwordterms_id.txt
sed -i 's/\bdocumentación_científica\b/TEST-0044/g' mavir04_multiwordterms_id.txt
sed -i 's/\benrique_torrejón\b/TEST-0054/g' mavir04_multiwordterms_id.txt
sed -i 's/\bfrancisco_garcía\b/TEST-0070/g' mavir04_multiwordterms_id.txt
sed -i 's/\binfecciones_urinarias\b/TEST-0091/g' mavir04_multiwordterms_id.txt
sed -i 's/\bluis_rodrigo\b/TEST-0102/g' mavir04_multiwordterms_id.txt
sed -i 's/\bnueva_gales_del_sur\b/TEST-0118/g' mavir04_multiwordterms_id.txt
sed -i 's/\bopen_directory\b/TEST-0122/g' mavir04_multiwordterms_id.txt
sed -i 's/\bpablo_serrano\b/TEST-0124/g' mavir04_multiwordterms_id.txt
sed -i 's/\bpaz_iglesias\b/TEST-0130/g' mavir04_multiwordterms_id.txt
sed -i 's/\bpenínsula_ibérica\b/TEST-0131/g' mavir04_multiwordterms_id.txt
sed -i 's/\bpepsi_twist\b/TEST-0132/g' mavir04_multiwordterms_id.txt
sed -i 's/\breino_unido\b/TEST-0160/g' mavir04_multiwordterms_id.txt
sed -i 's/\brío_tajo\b/TEST-0166/g' mavir04_multiwordterms_id.txt
sed -i 's/\bvicente_fox\b/TEST-0199/g' mavir04_multiwordterms_id.txt
sed -i 's/\bformato_digital\b/TEST-0204/g' mavir04_multiwordterms_id.txt
sed -i 's/\bpresidente_de_méjico\b/TEST-0211/g' mavir04_multiwordterms_id.txt
sed -i 's/\banswer_validation_exercise\b/TEST-0214/g' mavir04_multiwordterms_id.txt
sed -i 's/\bcross_language_evaluation_forum\b/TEST-0215/g' mavir04_multiwordterms_id.txt
sed -i 's/\bcristiano_ronaldo\b/TEST-0219/g' mavir04_multiwordterms_id.txt
sed -i 's/\bfernando_alonso\b/TEST-0220/g' mavir04_multiwordterms_id.txt
sed -i 's/\bpau_gasol\b/TEST-0221/g' mavir04_multiwordterms_id.txt
sed -i 's/\bcarolina_martín\b/TEST-0222/g' mavir04_multiwordterms_id.txt
cat mavir04_lower.words_id.time.score.txt mavir04_multiwordterms_id.txt > mavir04_lower.singlemultiwords_id.time.score.txt

./multiword_detection multiword_terms_STD_MAVIR_test.txt mavir11_lower.words.time.score.txt mavir11_multiwordterms.txt
cp mavir11_multiwordterms.txt mavir11_multiwordterms_id.txt
sed -i 's/\bantonio_moreno\b/TEST-0006/g' mavir11_multiwordterms_id.txt
sed -i 's/\bcoca_cola\b/TEST-0023/g' mavir11_multiwordterms_id.txt
sed -i 's/\bconsorcio_mavir\b/TEST-0030/g' mavir11_multiwordterms_id.txt
sed -i 's/\bdocumentación_científica\b/TEST-0044/g' mavir11_multiwordterms_id.txt
sed -i 's/\benrique_torrejón\b/TEST-0054/g' mavir11_multiwordterms_id.txt
sed -i 's/\bfrancisco_garcía\b/TEST-0070/g' mavir11_multiwordterms_id.txt
sed -i 's/\binfecciones_urinarias\b/TEST-0091/g' mavir11_multiwordterms_id.txt
sed -i 's/\bluis_rodrigo\b/TEST-0102/g' mavir11_multiwordterms_id.txt
sed -i 's/\bnueva_gales_del_sur\b/TEST-0118/g' mavir11_multiwordterms_id.txt
sed -i 's/\bopen_directory\b/TEST-0122/g' mavir11_multiwordterms_id.txt
sed -i 's/\bpablo_serrano\b/TEST-0124/g' mavir11_multiwordterms_id.txt
sed -i 's/\bpaz_iglesias\b/TEST-0130/g' mavir11_multiwordterms_id.txt
sed -i 's/\bpenínsula_ibérica\b/TEST-0131/g' mavir11_multiwordterms_id.txt
sed -i 's/\bpepsi_twist\b/TEST-0132/g' mavir11_multiwordterms_id.txt
sed -i 's/\breino_unido\b/TEST-0160/g' mavir11_multiwordterms_id.txt
sed -i 's/\brío_tajo\b/TEST-0166/g' mavir11_multiwordterms_id.txt
sed -i 's/\bvicente_fox\b/TEST-0199/g' mavir11_multiwordterms_id.txt
sed -i 's/\bformato_digital\b/TEST-0204/g' mavir11_multiwordterms_id.txt
sed -i 's/\bpresidente_de_méjico\b/TEST-0211/g' mavir11_multiwordterms_id.txt
sed -i 's/\banswer_validation_exercise\b/TEST-0214/g' mavir11_multiwordterms_id.txt
sed -i 's/\bcross_language_evaluation_forum\b/TEST-0215/g' mavir11_multiwordterms_id.txt
sed -i 's/\bcristiano_ronaldo\b/TEST-0219/g' mavir11_multiwordterms_id.txt
sed -i 's/\bfernando_alonso\b/TEST-0220/g' mavir11_multiwordterms_id.txt
sed -i 's/\bpau_gasol\b/TEST-0221/g' mavir11_multiwordterms_id.txt
sed -i 's/\bcarolina_martín\b/TEST-0222/g' mavir11_multiwordterms_id.txt
cat mavir11_lower.words_id.time.score.txt mavir11_multiwordterms_id.txt > mavir11_lower.singlemultiwords_id.time.score.txt

./multiword_detection multiword_terms_STD_MAVIR_test.txt mavir13_lower.words.time.score.txt mavir13_multiwordterms.txt
cp mavir13_multiwordterms.txt mavir13_multiwordterms_id.txt
sed -i 's/\bantonio_moreno\b/TEST-0006/g' mavir13_multiwordterms_id.txt
sed -i 's/\bcoca_cola\b/TEST-0023/g' mavir13_multiwordterms_id.txt
sed -i 's/\bconsorcio_mavir\b/TEST-0030/g' mavir13_multiwordterms_id.txt
sed -i 's/\bdocumentación_científica\b/TEST-0044/g' mavir13_multiwordterms_id.txt
sed -i 's/\benrique_torrejón\b/TEST-0054/g' mavir13_multiwordterms_id.txt
sed -i 's/\bfrancisco_garcía\b/TEST-0070/g' mavir13_multiwordterms_id.txt
sed -i 's/\binfecciones_urinarias\b/TEST-0091/g' mavir13_multiwordterms_id.txt
sed -i 's/\bluis_rodrigo\b/TEST-0102/g' mavir13_multiwordterms_id.txt
sed -i 's/\bnueva_gales_del_sur\b/TEST-0118/g' mavir13_multiwordterms_id.txt
sed -i 's/\bopen_directory\b/TEST-0122/g' mavir13_multiwordterms_id.txt
sed -i 's/\bpablo_serrano\b/TEST-0124/g' mavir13_multiwordterms_id.txt
sed -i 's/\bpaz_iglesias\b/TEST-0130/g' mavir13_multiwordterms_id.txt
sed -i 's/\bpenínsula_ibérica\b/TEST-0131/g' mavir13_multiwordterms_id.txt
sed -i 's/\bpepsi_twist\b/TEST-0132/g' mavir13_multiwordterms_id.txt
sed -i 's/\breino_unido\b/TEST-0160/g' mavir13_multiwordterms_id.txt
sed -i 's/\brío_tajo\b/TEST-0166/g' mavir13_multiwordterms_id.txt
sed -i 's/\bvicente_fox\b/TEST-0199/g' mavir13_multiwordterms_id.txt
sed -i 's/\bformato_digital\b/TEST-0204/g' mavir13_multiwordterms_id.txt
sed -i 's/\bpresidente_de_méjico\b/TEST-0211/g' mavir13_multiwordterms_id.txt
sed -i 's/\banswer_validation_exercise\b/TEST-0214/g' mavir13_multiwordterms_id.txt
sed -i 's/\bcross_language_evaluation_forum\b/TEST-0215/g' mavir13_multiwordterms_id.txt
sed -i 's/\bcristiano_ronaldo\b/TEST-0219/g' mavir13_multiwordterms_id.txt
sed -i 's/\bfernando_alonso\b/TEST-0220/g' mavir13_multiwordterms_id.txt
sed -i 's/\bpau_gasol\b/TEST-0221/g' mavir13_multiwordterms_id.txt
sed -i 's/\bcarolina_martín\b/TEST-0222/g' mavir13_multiwordterms_id.txt
cat mavir13_lower.words_id.time.score.txt mavir13_multiwordterms_id.txt > mavir13_lower.singlemultiwords_id.time.score.txt


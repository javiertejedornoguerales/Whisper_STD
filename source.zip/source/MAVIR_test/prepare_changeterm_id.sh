awk '{print tolower($1) " " $2 " " $3 " " $4 " " $3-$2}' mavir04.words.txt > mavir04_lower.words.txt
awk '{print $1 " " $2 " " $5 " " $4 " mavir04"}' mavir04_lower.words.txt > mavir04_lower.words.time.score.txt
cp mavir04_lower.words.time.score.txt mavir04_lower.words_id.time.score.txt

awk '{print tolower($1) " " $2 " " $3 " " $4 " " $3-$2}' mavir11.words.txt > mavir11_lower.words.txt
awk '{print $1 " " $2 " " $5 " " $4 " mavir11"}' mavir11_lower.words.txt > mavir11_lower.words.time.score.txt
sed -i 's/méxico/méjico/g' mavir11_lower.words.time.score.txt
cp mavir11_lower.words.time.score.txt mavir11_lower.words_id.time.score.txt

awk '{print tolower($1) " " $2 " " $3 " " $4 " " $3-$2}' mavir13.words.txt > mavir13_lower.words.txt
awk '{print $1 " " $2 " " $5 " " $4 " mavir13"}' mavir13_lower.words.txt > mavir13_lower.words.time.score.txt
sed -i 's/cocacola/coca_cola/g' mavir13_lower.words.time.score.txt
cp mavir13_lower.words.time.score.txt mavir13_lower.words_id.time.score.txt


awk 'BEGIN {inicio=0;} {if ($1 ~ /words/) inicio=1; else if (inicio==1) {if (($1 ~ /text/) || ($1 ~ /start/) || ($1 ~ /end/) || ($1 ~ /confidence/)) print $2;} if ($1 ~ /]/) inicio=0;}' mavir04.wav.words.json > mavir04.words.tmp.txt
sed -i 's/\"//g' mavir04.words.tmp.txt
sed -i 's/,//g' mavir04.words.tmp.txt
paste -d' ' - - - - < mavir04.words.tmp.txt > mavir04.words.tmp2.txt
awk '{gsub(/[^[:alnum:][:space:]]/,"",$1)} 1' mavir04.words.tmp2.txt > mavir04.words.txt

awk 'BEGIN {inicio=0;} {if ($1 ~ /words/) inicio=1; else if (inicio==1) {if (($1 ~ /text/) || ($1 ~ /start/) || ($1 ~ /end/) || ($1 ~ /confidence/)) print $2;} if ($1 ~ /]/) inicio=0;}' mavir11.wav.words.json > mavir11.words.tmp.txt
sed -i 's/\"//g' mavir11.words.tmp.txt
sed -i 's/,//g' mavir11.words.tmp.txt
paste -d' ' - - - - < mavir11.words.tmp.txt > mavir11.words.tmp2.txt
awk '{gsub(/[^[:alnum:][:space:]]/,"",$1)} 1' mavir11.words.tmp2.txt > mavir11.words.txt

awk 'BEGIN {inicio=0;} {if ($1 ~ /words/) inicio=1; else if (inicio==1) {if (($1 ~ /text/) || ($1 ~ /start/) || ($1 ~ /end/) || ($1 ~ /confidence/)) print $2;} if ($1 ~ /]/) inicio=0;}' mavir13.wav.words.json > mavir13.words.tmp.txt
sed -i 's/\"//g' mavir13.words.tmp.txt
sed -i 's/,//g' mavir13.words.tmp.txt
paste -d' ' - - - - < mavir13.words.tmp.txt > mavir13.words.tmp2.txt
awk '{gsub(/[^[:alnum:][:space:]]/,"",$1)} 1' mavir13.words.tmp2.txt > mavir13.words.txt

awk '{if ($1 ~ /TEST-/) print $1 " " $2 " " $3 " " $4 " " $5}' mavir04_lower.singlemultiwords_id.time.score.txt > mavir04.singlemultiterms.txt
awk '{if ($1 ~ /TEST-/) print $1 " " $2 " " $3 " " $4 " " $5}' mavir11_lower.singlemultiwords_id.time.score.txt > mavir11.singlemultiterms.txt
awk '{if ($1 ~ /TEST-/) print $1 " " $2 " " $3 " " $4 " " $5}' mavir13_lower.singlemultiwords_id.time.score.txt > mavir13.singlemultiterms.txt
cat mavir04.singlemultiterms.txt mavir11.singlemultiterms.txt mavir13.singlemultiterms.txt > all.singlemultiterms.txt

whisper_timestamped mavir04.wav -o mavir04 --model medium --language Spanish --accurate
whisper_timestamped mavir11.wav -o mavir11 --model medium --language Spanish --accurate
whisper_timestamped mavir13.wav -o mavir13 --model medium --language Spanish --accurate
